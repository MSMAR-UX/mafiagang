<?php
if (! function_exists('customLinks')) {
    function customLinks() {
        // setup custom links EXAMPLE BELOW:
        return [
            //'https://link1.com' => 'Discord',
            // 'https://link2.com' => 'Forum',
        ];
    }
}
