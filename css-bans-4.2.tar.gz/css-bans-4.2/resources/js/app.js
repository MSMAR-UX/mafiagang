import.meta.glob([
    '../images/**',
]);
