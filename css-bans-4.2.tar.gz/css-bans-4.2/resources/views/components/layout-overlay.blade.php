{{-- 

/**
*
* Created a new component <x-layout-overlay/>.
* 
*/

--}}

        <div class="overlay"></div>
        <div class="cs-overlay"></div>
        <div class="search-overlay"></div>