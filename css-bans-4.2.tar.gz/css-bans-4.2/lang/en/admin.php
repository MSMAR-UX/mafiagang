<?php

return [
    'skins' => 'Skins',
];
