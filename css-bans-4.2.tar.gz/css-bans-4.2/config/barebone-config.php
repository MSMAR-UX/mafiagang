<?php

return array(
    'layout' => array(

        /**
         * 
         * BAREBONE CONFIG
         * 
         * NOTE: Please Do not make any changes in LTR or RTL
         * 
         */

        'bb' => array(
            'layout-id' => 'barebone-structure-menu',
            'name' => 'Barebone Structure',
            'boxed' => true,
            'rtl' => false,
            'alt-menu' => false
        ),
        
        
    ),
);


