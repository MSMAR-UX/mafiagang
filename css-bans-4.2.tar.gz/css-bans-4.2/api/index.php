<?php

// Forward Vercel requests to public index.
require __DIR__ . "/" . "../public/index.php";
